package com.example.voca

class Voca {
    var eng : String
    var kor : String

    constructor(eng: String, kor: String) {
        this.eng = eng
        this.kor = kor
    }
}